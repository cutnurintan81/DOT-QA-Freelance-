<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Button_Login</name>
   <tag></tag>
   <elementGuidId>093026fd-d9a4-4513-bbae-a7f7a6c3ffea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@name = 'login']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>login</value>
      <webElementGuid>763377ea-aaa5-4490-a7a2-3d9a0cc95b98</webElementGuid>
   </webElementProperties>
</WebElementEntity>
