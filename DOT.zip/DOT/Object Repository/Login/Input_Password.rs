<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Input_Password</name>
   <tag></tag>
   <elementGuidId>902fcaf3-2c62-4e99-801b-24d1e0107996</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'pass']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>pass</value>
      <webElementGuid>226ca6ad-0bb1-4727-8755-b6d566181963</webElementGuid>
   </webElementProperties>
</WebElementEntity>
